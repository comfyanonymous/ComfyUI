// Shim for scripts/api.ts
export const api = window.comfyAPI.api.api;
