// Shim for scripts/widgets.ts
export const updateControlWidgetLabel = window.comfyAPI.widgets.updateControlWidgetLabel;
export const addValueControlWidget = window.comfyAPI.widgets.addValueControlWidget;
export const addValueControlWidgets = window.comfyAPI.widgets.addValueControlWidgets;
export const initWidgets = window.comfyAPI.widgets.initWidgets;
export const ComfyWidgets = window.comfyAPI.widgets.ComfyWidgets;
